
public class Funcionario {
	private Cargo cargo;
	private int id;
	private String nome;
	private double salario;
	private int idade;
	private char genero;
	
	public Funcionario() {
		
	}
	
	public Funcionario(Cargo cargo,int id, String nome, double salario, int idade, char genero) {
		this.cargo = cargo;
		this.id = id;
		this.nome = nome;
		this.salario = salario;
		this.idade = idade;
		this.genero = genero;
	}

	public Cargo getCargo() {
		return cargo;
	}

	public void setCargo(Cargo cargo) {
		this.cargo = cargo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public char getGenero() {
		return genero;
	}

	public void setGenero(char genero) {
		this.genero = genero;
	}
	
	
	
	
	
	
}
