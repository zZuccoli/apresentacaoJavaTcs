
public class Servico {
	private Funcionario funcionario;
	private Produto produto;
	private Transportadora transportadora;
	
	
	public Servico() {
		
	}

	public Servico(Funcionario funcionario, Produto produto, Transportadora transportadora) {
		this.funcionario = funcionario;
		this.produto = produto;
		this.transportadora = transportadora;
	}
	
}
