
public class Cargo {
	private Setor setor;
	private double valeAlimento;
	private double valeTransporte;
	private double planoSaude;
	private double planoOdonto;
	
	public Cargo(Setor setor, double valeAlimento, double valeTransporte, double planoSaude, double planoOdonto) {
		this.setor = setor;
		this.valeAlimento = valeAlimento;
		this.valeTransporte = valeTransporte;
		this.planoSaude = planoSaude;
		this.planoOdonto = planoOdonto;
	}
	
}
