
public enum Status {
	ABERTO,
	CONCLUÍDO,
	CANCELADO
}
