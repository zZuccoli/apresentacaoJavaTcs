
public enum Status {
	ABERTO,
	CONCLUÍDO
}
