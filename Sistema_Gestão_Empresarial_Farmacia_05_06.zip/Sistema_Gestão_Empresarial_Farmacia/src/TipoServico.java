
public enum TipoServico {
	COMPRA,
	VENDA
}
