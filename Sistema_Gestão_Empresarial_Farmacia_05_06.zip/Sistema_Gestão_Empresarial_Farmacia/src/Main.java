import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
		ArrayList<Produto> produtos = new ArrayList<>();
		Empresa farmacia = new Empresa();
		Cargo gerente = new Cargo(Setor.GERENTE_FILIAL, 500, 180, 3000, 3000);
		Funcionario f1 = new Funcionario(gerente, 1, "Caio", 50000, 29, 'm');
		Produto p = new Produto("Paracetamol", 1, 20, 40, 3);
		farmacia.adicionarProduto(p);
		
		Transportadora trans = new Transportadora("TG", 12, "Londrina" );
		
		//farmacia.listarProdutos();
		//farmacia.removerProduto(1);
		//farmacia.listarProdutos();
		
		Servico venda = new Servico(f1,trans, TipoServico.VENDA);
		
		Negocio neg = new Negocio(2, p);
	
		
		
	}
}
